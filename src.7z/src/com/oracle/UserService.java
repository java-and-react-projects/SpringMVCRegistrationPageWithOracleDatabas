package com.oracle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.oracle.UserDao;
import com.oracle.User;

@Component("userService")

public class UserService {
	


		 @Autowired
		 UserDao userDao;
		 
		public int registerUser(User user) {
			//System.out.println("TestService");
			return userDao.registerUser(user);

		}

		public User loginUser(User user) {
			
			return userDao.loginUser(user);
		}

	}



