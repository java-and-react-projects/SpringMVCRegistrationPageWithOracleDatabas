package com.oracle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.oracle.User;
import com.oracle.UserService;

@Controller

public class UserController {

	@Autowired
	UserService userService;
	User user;

	@RequestMapping(value = "/")
	public ModelAndView home(Model model) {

		User user = new User();
		model.addAttribute("user", user);
		ModelAndView modelAndView = new ModelAndView("login");
		System.out.println("Test @22");
		return modelAndView;
	}

	@RequestMapping(value = "/showLogin")
	public String showLogin(Model model) {
		model.addAttribute("user", new User());

		System.out.println("Test 2");
		return "login";
	}

	@RequestMapping(value = "/showRegister")
	public String showRegister(Model model) {

		System.out.println("registration execute");
		model.addAttribute("user", new User());
		return "register";
	}

	@RequestMapping(value = "/register")
	public String register(@ModelAttribute("user") User user, Model model) {
		int valid = userService.registerUser(user);

		System.out.println("test");
		if (valid == 2) {
			model.addAttribute("message", "All field are mandatory");
			return "success";
		}
		if (valid == 5) {
			model.addAttribute("message", "UserName  already exist in database! Please try another UserName");
			return "register";
		}

		if (valid == 9) {
			model.addAttribute("message", "Email id already exist in database! Please try another Email id");
			return "register";
		} else
			model.addAttribute("message", "Registered Successfully");
		return "Reg_success";
	}

	@RequestMapping(value = "/login")
	public String login(@ModelAttribute("user") User user, Model model) {
		User user1 = userService.loginUser(user);
		// System.out.println("Test 3");
		if (user1 != null) {
			// System.out.println("test 4");
			model.addAttribute("user", user1);
			model.addAttribute("message", "Login successfully");
			return "log_success";
		}
		model.addAttribute("message", "Invalid Credentials! Please try again");
		return "login";

	}

}
