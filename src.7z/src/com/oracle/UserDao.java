package com.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.RowMapper;

import com.oracle.User;

@Component("userDao")
public class UserDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public int registerUser(User user) {
		
  System.out.println(user.getGender());
		if (user.getFirstName() == "" || user.getLastName() == "" || user.getUserName() == "" || user.getEmail() == "" || user.getPassword() == ""
				|| user.getConfirmPassword() == "" || user.getDob() == ""
				 || user.getAddress() == "")
			return 2;
		
		if (isUserNameExists(user.getUserName())) {
			return 5;
		}
		if (isEmailIdExists(user.getEmail())) {
			return 9;
		}

		String sql = "INSERT INTO Users (FIRSTNAME, LASTNAME, USERNAME, PASSWORD, EMAIL, DOB, GENDER, ADDRESS)"
				+ " VALUES (?, ?, ?, ?, ?, ?,?, ?)";

		try {

			int num = jdbcTemplate.update(sql, user.getFirstName(),user.getLastName(), user.getUserName(), user.getPassword(), user.getEmail(),
					user.getDob(), user.getGender(), user.getAddress());
 		return num;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	


	private boolean isUserNameExists(String userName) {
		// TODO Auto-generated method stub
		String sql = "select * from Users where USERNAME='" + userName + "'";
		User users = null;
		try {
			users = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class));
			if (users != null)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return false;
	}
		
	
	private boolean isEmailIdExists(String email) {
		String sql = "select * from Users where EMAIL='" + email + "'";
		User users = null;
		try {
			users = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class));
			if (users != null)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return false;
	}


	public User loginUser(User user) {
		String sql = "select * from Users where USERNAME='" + user.getUserName() + "' and password='"
				+ user.getPassword() + "'";
		User users = null;
		try {
			users = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class));
			return users;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}

}
